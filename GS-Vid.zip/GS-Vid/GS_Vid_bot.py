import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, ConversationHandler, CallbackQueryHandler, \
    Application, MessageHandler, filters
import os
import logging
import mysql.connector
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)
TOKEN = "5669329144:AAFZdRVmNuoxJC6gFLznqqYYpfiCZtXr-lM"
START_ROUTES, END_ROUTES = range(2)

# Callback data
ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN = range(7)
Registered_Users = []
counting = []
# count = len(counting)
# count2 = count
plan = int(200000000)
Owners_ID = [2033966739,5027501500,1741249674,656882796]
#Opening Text Files

try:
    non_cu = open('NonCUsers.txt', 'r')
    content_non = non_cu.read()
except Exception as e:
    pass
# try:
#     f = open("users.txt", "r")
#     content2 = f.read()
# except Exception as e:
#     pass

#Saving Usernames from Database Into List
def save_to_list():
    conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
    mycursor = conn.cursor()
    mycursor.execute(f"SELECT User_Username FROM STORE")
    league1 = mycursor.fetchall()
    for x in league1:
        Registered_Users.append(x[0])

#Saving Count Numbers from Database into List
def save_count_to_list():
    conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
    mycursor = conn.cursor()
    mycursor.execute(f"SELECT Count FROM STORE")
    league2 = mycursor.fetchall()
    for x in league2:
        counting.append(x[0])


#To be able to write saved into txt file one line after another
def append_multiple_lines(file_name, lines_to_append):
    with open(file_name, "a+") as file_object:
        appendEOL = False
        file_object.seek(0)
        data = file_object.read(100)
        if len(data) > 0:
            appendEOL = True
        for line in lines_to_append:
            if appendEOL == True:
                file_object.write("\n")
            else:
                appendEOL = True
            file_object.write(line)

#Start the Bot
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
    mycursor = conn.cursor()

    """Send message on `/start`."""
    user = update.message.from_user
    logger.info("User %s started the conversation.", user.first_name)
    starter_info = update.effective_user.id
    keyboard = [
        [InlineKeyboardButton("+ADD ME TO A CHAT+",url= "https://t.me/GS_VerifyID_Bot?startgroup=test")]
                ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(f"Hello {update.effective_user.first_name} I am the GS-Verify ID Bot and i am here to "
                                    f"help you verify your usernames and IDs in a target group.!"
                                    f"\nVerify yourself,your workers,agents,e.t.c against impostors and scammers."
                                    f"\nHit /help to get more information on how to use me to my best."
                                    f"\nUse the /verify to jump straight to registering new Usernames/IDs"
                                    f"\nJoin @Bluechip_Hub my First Father.", reply_markup=reply_markup)
    print(f"Your ID is: {starter_info}")

#Start Verification Process
async def verify(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    starter_info = update.effective_user.id
    if starter_info in Owners_ID:
        keyboard = [
            [InlineKeyboardButton("Register A New Username", callback_data=str(ONE))],
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("In order to Verify:\nRegister the username you wish to verify and follow the prompt", reply_markup=reply_markup)
        return START_ROUTES
    else:
        await update.message.reply_text(f"{content_non}")

#Start Deleting Process
async def delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    starter_info = update.effective_user.id
    if starter_info in Owners_ID:
        keyboard = [
            [InlineKeyboardButton("Delete Selected Usernames", callback_data=str(TWO))]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("To Delete A Username:\nClick on the button below and follow the prompt", reply_markup=reply_markup)
        return START_ROUTES
    else:
        await update.message.reply_text(f"{content_non}")


#Commands
async def help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("These are the commands available:\n"
                                    "/start; Start me \n"
                                    "/help; Hit this to receive information on how to use this bot\n"
                                    "/pricing; Learn about the Bot Pricing\n"
                                    "/verify; use this to begin the user registration\n"
                                    "/delete; use this to delete specific users\n"
                                    "/cancel; use this to stop registration\n\n"
                                    "To use me in a group use the command below\n"
                                    " ?Confirm @Username\n\n"
                                    "Enjoy Me")

#Price
async def pricing(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    prices = open('pricing.txt', 'r')
    content_price = prices.read()
    await update.message.reply_text(f"{content_price}")
    prices.close()
    return START_ROUTES


#How to Register
async def register_details(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    f = open('registration.txt', 'r')
    content = f.read()
    await query.edit_message_text(f"{content}")
    f.close()
    return START_ROUTES

#Inputing Added Usernames Into Database
async def c_add_username(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    starter_info = update.effective_user.id
    if starter_info in Owners_ID:
        conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800",
                                       database="heroku_ef24cffb4ae39c0")
        mycursor = conn.cursor()
        global count,count2,lap, Reg_username
        try:
            counting.clear()
            save_count_to_list()
            count = int(len(counting))
            count2 = count
        except:
            pass

        lap = 0
        left = int(len(Registered_Users))
        if left <= plan:
            try:
                re_gister = update.message.text
                delimeter = " "
                if re_gister.startswith("REGISTER"):
                    cake = re_gister.split()
                    split_string = [x+delimeter for x in re_gister.split(delimeter) if x]
                    bag = split_string.remove("REGISTER: ")
                    Reg_username = split_string[0].strip()
                    nice = "".join(split_string)

                    def insert():
                        conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
                        mycursor = conn.cursor()
                        global count
                        count += 1
                        sql = "INSERT INTO STORE (Count, User_Username, Note) VALUES(%s, %s, %s);"
                        val = [(count), (Reg_username), (nice)]
                        mycursor.execute(sql, val)
                        conn.commit()

                    counting.clear()
                    save_count_to_list()
                    save_to_list()

                    if Reg_username in Registered_Users:
                        await update.message.reply_text(f"User {Reg_username} has already been registered in this bot")
                        Registered_Users.clear()
                    else:
                        if counting == []:
                            count += 1
                            sql = "INSERT INTO STORE (Count, User_Username, Note) VALUES(%s, %s, %s);"
                            val = [(count), (Reg_username), (nice)]
                            mycursor.execute(sql, val)
                            conn.commit()
                            save_count_to_list()
                            save_to_list()

                        else:
                            count_index = int((len(counting)) - 1)
                            main_count = counting[count_index]

                            if count < main_count:
                                count = (main_count)
                                count2 = count
                                insert()
                            else:
                                insert()

                        answer = f'Well Done! {Reg_username} registered :)'
                        await update.message.reply_text(answer)
                        Registered_Users.clear()
                        save_to_list()
                        save = {f"{count}: {Registered_Users[count2]}"}
                        append_multiple_lines("users.txt", save)

                        fusers = open("users.txt", "r")
                        content2 = fusers.read()

                        await update.message.reply_text(text=f"These are the Registered Usernames:\n"
                                                             f"{content2}\n\n"
                                                             f"Infinity ∞ slots left\n\n"
                                                             f"Total Infinity Slots")

                        fusers.close()
                        await update.message.reply_text(
                            f"The ID for {Reg_username} has been verified successfully and the user information has been stored in our database\n\n"
                            f"Hit /cancel to quit the registration, to re-register again hit /verify and to delete specific username hit /delete")
                        count2 += 1
                        Registered_Users.clear()

            except Exception as e:
                print(e)
        else:
            await update.message.reply_text(f"Please Upgrade your plan to register more usernames\n"
                                            f"Check /pricing for details\n"
                                            f"Contact Developer & Support @gentlespree to upgrade")
    else:
        await update.message.reply_text(f"{content_non}")

#End Conversation Handler
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    starter_info = update.effective_user.id
    if starter_info in Owners_ID:
        await update.message.reply_text(f"Process Is Halted.")
        return ConversationHandler.END
    else:
        await update.message.reply_text(f"{content_non}")

#Asking for Specific Usernames to delete from Database
async def cancel_usernames(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    fsecond = open("users.txt", "r")
    content2 = fsecond.read()
    await query.edit_message_text(f"These are the Existing Usernames;\n"
                                  f"{content2}\n\n"
                                  f"Send the NumberID of the Username you wish to delete!")
    fsecond.close()
    return START_ROUTES

def constant():
    index_start = None
    count_start = 1

#Deleting Specific Usernames from Database
async def delete_registered(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
    mycursor = conn.cursor()

    try:
        getting_noID = update.message.text
        save_to_list()
        deleted_username = Registered_Users[int(getting_noID) -1 ]

        mycursor.execute(f"DELETE from STORE where Count = {getting_noID}")
        conn.commit()
        await update.message.reply_text(f"The Verification Information for {deleted_username} has been deleted from the server.\n"
                                        f"Hit /delete to delete another username. Hit /verify to register new usernames")
        Registered_Users.clear()
#        print(counting)
        counting.clear()
        save_count_to_list()
#        print(f"Second counting= {counting}")
        id_stop = len(counting)+ 1
        index_start = 0
        count_start = 1
        # constant = 0
        # constant2 = 1
        deletingtxt = open('users.txt', 'r+')
        deletingtxt.truncate(0)
        deletingtxt.close()

        while count_start < id_stop:
            Registered_Users.clear()
            save_to_list()
            begin = counting[index_start]
            mycursor.execute(f"UPDATE STORE set Count = {count_start} where Count = {begin}")
            conn.commit()
            # print(Registered_Users)
            # print(index_start)
            save2 = {f"{count_start}: {Registered_Users[index_start]}"}
            append_multiple_lines("users.txt", save2)

            count_start += 1
            index_start += 1
        constant()
        save_count_to_list()
        counting.clear()
    except Exception as e:
        print(e)
        await update.message.reply_text("Input Warning!. Kindly Ensure you always put an integer to delete.\n If faced with any issue Hit /cancel and start the bot again")
        pass
    return ConversationHandler.END


#Sending Required Information to Group
async def new_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    conn = mysql.connector.connect(host="us-cdbr-east-06.cleardb.net", user="babfdb5e9770b8", password="876ea800", database="heroku_ef24cffb4ae39c0")
    mycursor = conn.cursor()
    mycursor.execute(f"SELECT * FROM STORE")
    league = mycursor.fetchall()
    save_to_list()

    message = update.message.text
    for member in update.message.new_chat_members:
        if member.username == 'GS_VerifyID_Bot':
            await update.message.reply_text('Welcome')
        else:
            pass
    try:
        if message.startswith("?Confirm"):
            split_confirm = message.split()
            split_confirm.remove("?Confirm")
            if split_confirm[0].startswith("@"):
                for row in league:
                    if split_confirm[0] in row:
                        send_note = row[2]
                #         print(send_note)
                # print(split_confirm[0])
                # print(Registered_Users)
                if split_confirm[0] in Registered_Users:
#                    print("Im sure it checked here")
                    await update.message.reply_text(f"{send_note}")
#                    print("Listened")
                    Registered_Users.clear()
                else:
                    await update.message.reply_text(f"BEWARE OF SCAMMERS!\nWe don't have this user registered in our server yet!")
        else:
            pass
    except Exception as e:
        print(e)
        pass

#Main Function Holding All Handlers
def main() -> None:
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("verify", verify)],
        states={
            START_ROUTES: [
                CallbackQueryHandler(register_details, f"^{ONE}$"),
                MessageHandler(filters.TEXT & (~ filters.COMMAND), c_add_username)
            ],
             END_ROUTES: [
                 CallbackQueryHandler(cancel_usernames, f"^{TWO}$"),
                 MessageHandler(filters.TEXT & (~ filters.COMMAND), delete_registered)
             ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    conv_handler2 = ConversationHandler(
        entry_points=[CommandHandler("delete", delete)],
        states={
            START_ROUTES: [
                CallbackQueryHandler(cancel_usernames, f"^{TWO}$"),
                MessageHandler(filters.TEXT & (~ filters.COMMAND), delete_registered)
            ],
            END_ROUTES: [
                CallbackQueryHandler(cancel, f"^{TWO}$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(conv_handler)
    app.add_handler(conv_handler2)
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler('help', help))
    app.add_handler(CommandHandler('pricing', pricing))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, new_member))
    app.add_handler(MessageHandler(filters.TEXT & (~ filters.COMMAND), new_member))

    app.run_polling()

if __name__ == "__main__":
    main()